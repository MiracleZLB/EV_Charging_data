# EV-Charging-Station-Usage-of-California-City

Dataset_Description.md - Contains the description about the dataset.

EDA_final.ipynb - Contains the all the data analysis on the dataset.

waiting_time_prediction.md - Contains description and all the experiments related to waiting time.

waiting_time_regression.ipynb - Contains all the different types of regression for prediction of waiting time.

waiting_time_neural_network.ipynb - Contains neural network model on waiting time.

Fee_Prediction.ipynb - Contains all the different types of regression for prediction of fee.

finalEDA_arth.ipynb - Containas additonal analysis by Arth


# Contribution
Om (202001462) : Neural Network for predicting waiting time class ,Regresssion model for predicting waiting time class

Hetav (202001447) : EDA, Fee_Prediction Model, Linear regresssion model for predicting waiting time class

Vrund (202001075) : EDA, Fee_Prediction Model, Linear regresssion model for predicting waiting time class

Vandan (202001041) : EDA

Arth (202001274) : EDA

Ayush (202001126) :EDA
